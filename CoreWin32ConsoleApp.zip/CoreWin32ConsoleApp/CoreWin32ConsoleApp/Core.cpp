#pragma once
//#include "stdafx.h"
#include "pch.h"
#include <vector>
#include "Core.h"

CoreNativeClass::CoreNativeClass(int * pInt, int arrsize)
{
	vector<int> v;
	for (int i = 0; i < 4; i++)
	{
		v.push_back(0);
	}
	//pInt[0] = SetGraphicMode1();
	//pInt[1] = SetGraphicMode2();
	//pInt[2] = SetGraphicMode3();
	//pInt[3] = SetGraphicMode4();
	v[0] = SetFoo_1();
	v[1] = SetFoo_2();
	v[2] = SetFoo_3();
	v[3] = SetFoo_4();

	this->vec = v;

	pInt[0] = vec[0];
	pInt[1] = vec[1];
	pInt[2] = vec[2];
	pInt[3] = vec[3];
}

void CoreNativeClass::Copy_vec_to_pArr(int * pArr, int arraySize)
{
	for (int i = 0; i < this->vec.size(); i++)
	{
		pArr[i] = vec[i];
	}
}

int CoreNativeClass::Foo_1()
{
	return 1;
}
int CoreNativeClass::Foo_2()
{
	return 2;
}
int CoreNativeClass::Foo_3()
{
	return 3;
}
int CoreNativeClass::Foo_4()
{
	return 4;
}
//--------------------------------------------------------------------------------------------------------------

int CoreNativeClass::SetFoo_1()
{	
	return Foo_1();		
}
int CoreNativeClass::SetFoo_2()
{
	return Foo_2();
}
int CoreNativeClass::SetFoo_3()
{
	return Foo_3();
}
int CoreNativeClass::SetFoo_4()
{
	return Foo_4();
}

#pragma once
#include <vector>

using namespace std;

class CoreNativeClass
{
public:
	CoreNativeClass(int * pInt, int arrSize);
	//int rv;

	int Foo_1();
	int Foo_2();
	int Foo_3();
	int Foo_4();
	
	int SetFoo_1();
	int SetFoo_2();
	int SetFoo_3();
	int SetFoo_4();
	
	void Copy_vec_to_pArr(int * pArr, int arraySize);

private:
	vector<int> vec;
};
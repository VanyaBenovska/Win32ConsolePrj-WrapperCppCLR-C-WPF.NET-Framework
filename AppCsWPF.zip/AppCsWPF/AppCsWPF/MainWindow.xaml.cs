﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Core;

namespace AppCsWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txbResult_ASM_Foo_1.Text = "Waiting to press 'Start'";
            //txbResult_ASM_Foo_2.Text = "Waiting to press 'Start'";
        }

        void OnClickStart(object sender, RoutedEventArgs e)
        {
            int numberElements = 4;
            int[] myArray = new int[numberElements];

            for (int i = 0; i < numberElements; i++)
            {
                myArray[i] = 0;
            }
        
            unsafe
            {
                fixed (int* pmyArray = &myArray[0])
                {
                    Core.Wrapper controlCpp = new Core.Wrapper(pmyArray, numberElements);

                    //  controlCpp.CalculateAll();

                    int num1 = pmyArray[0];
                    int num2 = pmyArray[1];
                    int num3 = pmyArray[2];
                    int num4 = pmyArray[3];

                    txbResult_ASM_Foo_1.Text = num1.ToString();
                    txbResult_ASM_Foo_2.Text = num2.ToString();
                    txbResult_ASM_Foo_3.Text = num3.ToString();
                    txbResult_ASM_Foo_4.Text = num4.ToString();

                }
            }

            //unsafe
            //{
            //    // numberElements = 4;
            //    int[] myArray2 = new int[numberElements];
            //    int* ptr2 = &myArray2[0];

            //    using (Wrapper foo2 = new Wrapper(pmyArray2, numberElements))
            //    // Using block is here to make sure we release native memory right away
            //    {
            //        try
            //        {
            //            int a = foo2.SetFoo_1();
            //            txbResult_ASM_Foo_1.Text = a.ToString();
            //        }
            //        catch (Exception)
            //        {
            //            // MessageBox.Show(ex.Message);
            //            //  MessageBox.Show(ex.GetType().ToString());
            //            txbResult_ASM_Foo_1.Text = "Error";
            //        }

            //        try
            //        {
            //            int b = foo2.SetFoo_2();
            //            txbResult_ASM_Foo_2.Text = b.ToString();
            //        }
            //        catch (Exception)
            //        {
            //            txbResult_ASM_Foo_2.Text = "Error";
            //        }
            //    }
            //}
        }
    }
}

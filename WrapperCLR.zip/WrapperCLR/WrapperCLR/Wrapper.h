#pragma once

#include "D:\data2019\09_C++CLI_3_Solutions_ptr_to_vector\CoreWin32ConsoleApp\CoreWin32ConsoleApp\Core.cpp"
#include "D:\data2019\09_C++CLI_3_Solutions_ptr_to_vector\CoreWin32ConsoleApp\CoreWin32ConsoleApp\Core.h"

using namespace System;

namespace Core {
	public ref class Wrapper
	{		
	public:
		Wrapper(int * pInt, int arraySize);
		//void RunAsmTests();
		//void CopyVecDataToPint();

		void CalculateAll(int * pInt, int arraySize);

	public:
		CoreNativeClass * ptrNative;
	};
}

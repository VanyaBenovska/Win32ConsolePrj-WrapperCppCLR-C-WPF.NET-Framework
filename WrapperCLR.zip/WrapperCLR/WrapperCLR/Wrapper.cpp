#include "stdafx.h"

#include "Wrapper.h"

#include "D:\data2019\09_C++CLI_3_Solutions_ptr_to_vector\CoreWin32ConsoleApp\CoreWin32ConsoleApp\Core.cpp"
#include "D:\data2019\09_C++CLI_3_Solutions_ptr_to_vector\CoreWin32ConsoleApp\CoreWin32ConsoleApp\Core.h"

Core::Wrapper::Wrapper(int * pInt, int arraySize)
{
	ptrNative = new CoreNativeClass(pInt, arraySize);

	//CalculateAll(pInt, arraySize);
}

void Core::Wrapper::CalculateAll(int * pInt, int arraySize)
{
	ptrNative->Copy_vec_to_pArr(pInt, arraySize);
}


//void Core::Wrapper::RunAsmTests()
//{
//	ptrNative->SetFoo_1();
//	ptrNative->SetFoo_2();
//	ptrNative->SetFoo_3();
//	ptrNative->SetFoo_4();
//}

//void Core::Wrapper::CopyVecDataToPint()
//{
//	pNGraphicsC->Copy_vec_to_pArr(this -> pArr);
//}

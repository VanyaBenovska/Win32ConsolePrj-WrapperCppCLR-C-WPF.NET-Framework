#pragma once

using namespace System;

namespace WrapperCLR {
	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
